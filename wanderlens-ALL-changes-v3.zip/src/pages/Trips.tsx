import {
  useListTrips,
  getListTripsQueryKey,
  useMergeTrips,
  getGetTripQueryOptions,
  getGetTripPhotosQueryOptions,
  getGetStatsQueryKey,
  getGetTripsMapQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Link, useLocation, useSearch } from "wouter";
import { format } from "date-fns";
import {
  MapPin,
  GitMerge,
  X,
  CheckCircle2,
  ArrowRight,
  Search,
} from "lucide-react";
import { cardUrl, cardSrcSet } from "@/lib/photoUrl";
import { useAuth, isUnauthorized } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import {
  tripsUrl,
  rememberTripsUrl,
  saveTripsScroll,
  readTripsScroll,
} from "@/lib/tripsReturn";
import { useEffect, useMemo, useRef, useState } from "react";
import { cn } from "@/lib/utils";

export default function Trips() {
  const { data: trips, isLoading } = useListTrips({
    query: { queryKey: getListTripsQueryKey() },
  });
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();
  const { isAdmin, handleUnauthorized } = useAuth();
  const { toast } = useToast();
  const scrollRef = useRef<HTMLDivElement>(null);

  const [mergeMode, setMergeMode] = useState(false);
  const [selected, setSelected] = useState<number[]>([]);

  const { mutate: mergeTrips, isPending: isMerging } = useMergeTrips({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListTripsQueryKey() });
        // A merge removes a trip: the totals on the map page change too.
        queryClient.invalidateQueries({ queryKey: getGetStatsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetTripsMapQueryKey() });
        exitMergeMode();
      },
      onError: (err) => {
        if (isUnauthorized(err)) handleUnauthorized();
        toast({
          variant: "destructive",
          title: isUnauthorized(err) ? "Admin sign-in required" : "Merge failed",
        });
      },
    },
  });

  // The search text lives in the URL (?q=...) so that back/forward, refresh
  // and shared links all restore the same filtered view.
  const search = useSearch();
  const urlQuery = useMemo(() => new URLSearchParams(search).get("q") ?? "", [search]);
  const [query, setQuery] = useState(urlQuery);

  // Only act while /trips is really the active page. When an album is opening
  // (its code may still be loading) this component can briefly still be
  // mounted while the URL already points at /trips/:id, where there is no ?q=
  // — it must not mistake that for "the user cleared the search".
  const [path] = useLocation();
  const onTripsPage = path === "/trips";

  // Browser back/forward (or a link) changed ?q= -> follow it.
  const lastUrlQuery = useRef(urlQuery);
  useEffect(() => {
    if (!onTripsPage || lastUrlQuery.current === urlQuery) return;
    lastUrlQuery.current = urlQuery;
    setQuery((current) => (current.trim() === urlQuery.trim() ? current : urlQuery));
  }, [urlQuery, onTripsPage]);

  // Typing -> update ?q= in place (replace, so each keystroke doesn't add a
  // history entry) and remember it for the album page's back arrow.
  const currentUrl = tripsUrl(query);
  useEffect(() => {
    if (!onTripsPage) return;
    if (query.trim() !== urlQuery.trim()) {
      lastUrlQuery.current = query.trim();
      navigate(currentUrl, { replace: true });
    }
    rememberTripsUrl(currentUrl);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentUrl, onTripsPage]);

  // Restore scroll position when coming back from an album.
  const restoredRef = useRef(false);
  useEffect(() => {
    if (restoredRef.current || isLoading || !trips || !scrollRef.current) return;
    restoredRef.current = true;
    const top = readTripsScroll(tripsUrl(urlQuery));
    if (top) scrollRef.current.scrollTop = top;
  }, [isLoading, trips, urlQuery]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => saveTripsScroll(tripsUrl(query), el.scrollTop));
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      cancelAnimationFrame(raf);
      el.removeEventListener("scroll", onScroll);
    };
  }, [query]);

  // Warm the cache for the album the pointer is heading to.
  const prefetchTrip = (id: number) => {
    queryClient.prefetchQuery(getGetTripQueryOptions(id));
    queryClient.prefetchQuery(getGetTripPhotosQueryOptions(id));
  };

  // Case- and accent-insensitive: "zurich" matches "Zürich"
  const normalize = (v: string) =>
    v
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase();

  const filteredTrips = useMemo(() => {
    const terms = normalize(query).split(/\s+/).filter(Boolean);
    if (!trips || terms.length === 0) return trips ?? [];
    return trips.filter((t) => {
      const date = new Date(t.startDate);
      const haystack = normalize(
        [
          t.name,
          t.locationName ?? "",
          format(date, "MMM yyyy"),
          format(date, "MMMM yyyy"),
        ].join(" ")
      );
      // every word must match somewhere (e.g. "paris 2023")
      return terms.every((term) => haystack.includes(term));
    });
  }, [trips, query]);

  const isSearching = query.trim().length > 0;

  const canMerge = isAdmin && (trips?.length ?? 0) >= 2;

  function enterMergeMode() {
    setMergeMode(true);
    setSelected([]);
  }

  function exitMergeMode() {
    setMergeMode(false);
    setSelected([]);
  }

  function toggleSelect(id: number) {
    setSelected((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      if (prev.length >= 2) return prev;
      return [...prev, id];
    });
  }

  function confirmMerge() {
    if (selected.length !== 2 || isMerging) return;
    const [sourceId, targetId] = selected;
    mergeTrips({ id: targetId, data: { sourceId } });
  }

  const sourceTrip = trips?.find((t) => t.id === selected[0]);
  const targetTrip = trips?.find((t) => t.id === selected[1]);

  return (
    <div ref={scrollRef} className="h-full w-full overflow-y-auto p-8 md:p-12">
      <div className="max-w-7xl mx-auto space-y-12">
        <header className="flex items-start justify-between gap-4">
          <div className="space-y-4 max-w-2xl">
            <motion.h1
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl md:text-5xl font-serif tracking-tight"
            >
              Trips
            </motion.h1>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.1 }}
              className="text-muted-foreground text-lg leading-relaxed"
            >
              {mergeMode
                ? "Select two trips to merge — the second trip you pick will absorb the first."
                : "A cinematic archive of places seen and distances traveled."}
            </motion.p>
          </div>

          {canMerge && !isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.15 }}
              className="flex-shrink-0 mt-2"
            >
              {mergeMode ? (
                <button
                  onClick={exitMergeMode}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border text-muted-foreground hover:text-foreground hover:border-foreground/40 transition-colors text-sm"
                >
                  <X className="w-4 h-4" />
                  Cancel
                </button>
              ) : (
                <button
                  onClick={enterMergeMode}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border text-muted-foreground hover:text-foreground hover:border-foreground/40 transition-colors text-sm"
                >
                  <GitMerge className="w-4 h-4" />
                  Merge trips
                </button>
              )}
            </motion.div>
          )}
        </header>

        {!isLoading && (trips?.length ?? 0) > 0 && (
          <div className="flex items-center gap-4">
            <div className="relative w-full max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Escape") setQuery("");
                }}
                placeholder="Search by name, place or date…"
                aria-label="Search trips"
                className="w-full pl-9 pr-9 py-2 rounded-lg border border-border bg-transparent text-sm placeholder:text-muted-foreground focus:outline-none focus:border-foreground/40 transition-colors"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery("")}
                  aria-label="Clear search"
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-muted-foreground hover:text-foreground transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
            {isSearching && (
              <span className="text-sm text-muted-foreground whitespace-nowrap">
                {filteredTrips.length} of {trips?.length}{" "}
                {trips?.length === 1 ? "trip" : "trips"}
              </span>
            )}
          </div>
        )}

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div
                key={i}
                className="aspect-[4/5] bg-secondary/50 animate-pulse rounded-xl"
              />
            ))}
          </div>
        ) : trips?.length === 0 ? (
          <div className="flex flex-col items-center justify-center text-center p-24 border border-dashed border-border/50 rounded-2xl bg-secondary/10">
            <MapPin className="text-muted-foreground w-12 h-12 mb-6 opacity-50" />
            <h3 className="font-serif text-2xl text-foreground mb-2">
              No journeys yet
            </h3>
            <p className="text-muted-foreground mb-6 max-w-md">
              Upload your photos and we'll automatically group them into
              beautiful, cinematic trips based on time and location.
            </p>
            <Link
              href="/upload"
              className="bg-primary text-primary-foreground px-6 py-3 rounded-md text-sm font-medium tracking-wide hover:opacity-90 transition-opacity"
            >
              Start Uploading
            </Link>
          </div>
        ) : filteredTrips.length === 0 ? (
          <div className="flex flex-col items-center justify-center text-center p-24 border border-dashed border-border/50 rounded-2xl bg-secondary/10">
            <Search className="text-muted-foreground w-12 h-12 mb-6 opacity-50" />
            <h3 className="font-serif text-2xl text-foreground mb-2">
              No matching trips
            </h3>
            <p className="text-muted-foreground mb-6 max-w-md">
              Nothing matches “{query.trim()}”. Try a different name, place or
              year.
            </p>
            <button
              onClick={() => setQuery("")}
              className="px-4 py-2 rounded-lg border border-border text-muted-foreground hover:text-foreground hover:border-foreground/40 transition-colors text-sm"
            >
              Clear search
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 auto-rows-[300px]">
            {filteredTrips.map((trip, i) => {
              const coverPhoto = trip.coverPhotoPath
                ? {
                    cloudinaryUrl: trip.coverCloudinaryUrl ?? null,
                    filename: trip.coverPhotoPath.split("/").pop() ?? "",
                  }
                : null;
              const url = coverPhoto ? cardUrl(coverPhoto, 800) : null;

              const isLarge = i % 5 === 0;
              const isSelected = selected.includes(trip.id);
              const selectionIndex = selected.indexOf(trip.id);
              const isSource = selectionIndex === 0;
              const isTarget = selectionIndex === 1;
              const isDisabled =
                mergeMode && selected.length === 2 && !isSelected;

              return (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{
                    delay: Math.min(i, 9) * 0.04,
                    duration: 0.6,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                  key={trip.id}
                  className={cn(
                    "group relative overflow-hidden rounded-xl bg-secondary",
                    isLarge ? "row-span-2" : "row-span-1",
                    mergeMode && "cursor-pointer",
                    isSelected &&
                      "ring-2 ring-offset-2 ring-offset-background",
                    isSource && "ring-amber-400",
                    isTarget && "ring-emerald-400",
                    isDisabled && "opacity-40"
                  )}
                  onPointerEnter={() => !mergeMode && prefetchTrip(trip.id)}
                  onClick={() => {
                    if (mergeMode) {
                      toggleSelect(trip.id);
                    } else {
                      navigate(`/trips/${trip.id}`);
                    }
                  }}
                >
                  {!mergeMode && (
                    <Link
                      href={`/trips/${trip.id}`}
                      className="absolute inset-0 z-10"
                      onClick={(e) => e.stopPropagation()}
                    />
                  )}

                  {url ? (
                    <img
                      src={url}
                      srcSet={coverPhoto ? cardSrcSet(coverPhoto) : undefined}
                      sizes="(min-width: 1024px) 33vw, (min-width: 768px) 50vw, 100vw"
                      alt={trip.name}
                      loading={i < 6 ? "eager" : "lazy"}
                      fetchPriority={i < 3 ? "high" : "auto"}
                      decoding="async"
                      className={cn(
                        "absolute inset-0 w-full h-full object-cover transition-all duration-1000",
                        !mergeMode &&
                          "group-hover:scale-105 group-hover:brightness-75"
                      )}
                    />
                  ) : (
                    <div className="absolute inset-0 flex items-center justify-center bg-card">
                      <MapPin className="text-muted-foreground opacity-20 w-12 h-12" />
                    </div>
                  )}

                  <div
                    className={cn(
                      "absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent opacity-80 transition-opacity duration-500",
                      !mergeMode && "group-hover:opacity-100"
                    )}
                  />

                  {/* Selection badge */}
                  <AnimatePresence>
                    {isSelected && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.6 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.6 }}
                        className={cn(
                          "absolute top-3 right-3 z-20 flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold backdrop-blur-sm",
                          isSource
                            ? "bg-amber-400/20 text-amber-300 border border-amber-400/40"
                            : "bg-emerald-400/20 text-emerald-300 border border-emerald-400/40"
                        )}
                      >
                        <CheckCircle2 className="w-3 h-3" />
                        {isSource ? "Merge from" : "Merge into"}
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <div
                    className={cn(
                      "absolute bottom-0 left-0 right-0 p-6 flex flex-col gap-1 transform transition-transform duration-500",
                      !mergeMode &&
                        "translate-y-2 group-hover:translate-y-0"
                    )}
                  >
                    <span className="tracking-widest uppercase text-primary font-medium">
                      {format(new Date(trip.startDate), "MMM yyyy")}
                    </span>
                    <h2 className="text-2xl font-serif text-white">
                      {trip.name}
                    </h2>
                    <p
                      className={cn(
                        "text-sm text-gray-300 transition-opacity duration-500",
                        mergeMode
                          ? "opacity-70"
                          : "opacity-0 group-hover:opacity-100 delay-100"
                      )}
                    >
                      {trip.photoCount} photos
                      {trip.locationName ? ` · ${trip.locationName}` : ""}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Merge confirmation bar */}
      <AnimatePresence>
        {mergeMode && selected.length === 2 && (
          <motion.div
            initial={{ opacity: 0, y: 80 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 80 }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}
            className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 flex items-center gap-4 px-6 py-4 rounded-2xl bg-card border border-border shadow-2xl shadow-black/60 backdrop-blur-sm max-w-xl w-[calc(100vw-3rem)]"
          >
            <div className="flex-1 min-w-0">
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                Merge trips
              </p>
              <div className="flex items-center gap-2 text-sm font-medium truncate">
                <span className="text-amber-400 truncate">
                  {sourceTrip?.name}
                </span>
                <ArrowRight className="w-3.5 h-3.5 flex-shrink-0 text-muted-foreground" />
                <span className="text-emerald-400 truncate">
                  {targetTrip?.name}
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {(sourceTrip?.photoCount ?? 0) +
                  (targetTrip?.photoCount ?? 0)}{" "}
                photos total · "{sourceTrip?.name}" will be deleted
              </p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <button
                onClick={exitMergeMode}
                className="px-3 py-1.5 rounded-lg text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={confirmMerge}
                disabled={isMerging}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-opacity disabled:opacity-50"
              >
                <GitMerge className="w-3.5 h-3.5" />
                {isMerging ? "Merging…" : "Merge"}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}